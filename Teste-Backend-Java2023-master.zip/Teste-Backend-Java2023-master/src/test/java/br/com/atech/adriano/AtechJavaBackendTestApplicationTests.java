package br.com.atech.adriano;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AtechJavaBackendTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
