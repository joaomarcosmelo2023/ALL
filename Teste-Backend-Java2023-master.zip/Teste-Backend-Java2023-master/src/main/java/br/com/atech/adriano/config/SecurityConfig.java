package br.com.atech.adriano.config;

public class SecurityConfig {

	public SecurityConfig() {
		
	}
}
