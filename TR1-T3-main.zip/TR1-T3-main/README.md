# TR1-T3

# TR1_Trabalho_2e3

### Alguns Links
- [Google Drive](https://drive.google.com/drive/folders/1E2MhksXMG_WjuR-WTSJlocG18wgDAw81?usp=sharing)
- [Google Drive](https://drive.google.com/drive/folders/1Kdg7BMJH1lbWvTNx7MuSmWBJ_B6N0Xxt)
