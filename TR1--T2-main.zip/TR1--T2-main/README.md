# TR1--T2
Teleinformática e Redes 1

Camada Física - TR1

Trabalho 2 - Teleinformática e Redes 1

Unb - 2022/2

Especificação do trabalho

Simular o funcionamento da camada física por meio da implementação dos seguintes protocolos:

Binário

Manchester

Bipolar
