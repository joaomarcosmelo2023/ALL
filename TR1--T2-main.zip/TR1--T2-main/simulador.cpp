#include <iostream>
#include <stdio.h>
#include <string>
#include <stdlib.h>
#include "camadafisicaprotocolo.cpp"
using namespace std;

int main (){
	int size = 32;
	int quadro[size];

	AplicacaoTransmissora();
}
