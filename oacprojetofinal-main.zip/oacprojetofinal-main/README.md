# oacprojetofinal
oac-projetofinal

# Mario-Game-ASM
co-creator: github.com/joaomarcosmelo
Assembly Language x86 based Mario Game using Assembly Graphics.
https://github.com/joaomarcosmelo/oacprojetofinal

https://converter.app/pt/to-zip/
https://www.youtube.com/watch?v=53Z-oyvzIag
https://www.youtube.com/watch?v=53Z-oyvzIag
https://www.youtube.com/watch?v=53Z-oyvzIag
https://www.youtube.com/watch?v=mVKlyUY9M6Y
https://www.youtube.com/watch?v=mVKlyUY9M6Y

# Mario-Game-ASM

co-creator: github.com/joaomarcosmelo
Assembly Language x86 based Mario Game using Assembly Graphics.


Referências:
https://supermario-game.com/pt
Referência: https://supermario-game.com/pt
Sprite Sheets: https://www.spriters-resource.com/nes/supermariobros/
Bom divertimento! kkkkkk
Referência: https://supermario-game.com/pt
Sprite Sheets: https://www.spriters-resource.com/nes/supermariobroshttps://github.com/joaomarcosmelo

Referências:
https://supermario-game.com/pt
Referência: https://supermario-game.com/pt
Sprite Sheets: https://www.spriters-resource.com/nes/supermariobros/
Bom divertimento! kkkkkk
